package parser;

public abstract class Query {
    public abstract String getType();
}