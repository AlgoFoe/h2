package index;

// BTree.java
public class BTree<K extends Comparable<K>, V> {
    // Define BTreeNode<K, V> inner class here
    // insert, search, delete
}
