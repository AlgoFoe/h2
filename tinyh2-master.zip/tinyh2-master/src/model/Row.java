package model;

import java.util.List;

public class Row {
    public final List<String> values;  // each value as String

    public Row(List<String> values) {
        this.values = values;
    }
}
